
import React from "react";
import ReactDOM from "react-dom/client";

const BBWebsite = () => {
  return (
    <div className="bg-white font-sans text-gray-800">
      <header className="bg-blue-900 text-white py-10 text-center px-4">
        <h1 className="text-5xl font-extrabold mb-4">B&B Cleaning Solutions</h1>
        <p className="text-xl max-w-2xl mx-auto">
          Reliable carpet, upholstery, laminate cleaning & mobile car interior detailing across Calgary. Premium German products & Karcher technology ensure deep, effective cleaning every time.
        </p>
        <button className="mt-6 bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-semibold py-3 px-6 rounded-lg text-lg">Get a Free Quote</button>
      </header>

      <section className="max-w-6xl mx-auto py-12 px-4 grid md:grid-cols-2 gap-10">
        <div>
          <h2 className="text-3xl font-bold mb-4">Our Services</h2>
          <ul className="space-y-3 text-lg list-disc list-inside">
            <li>Deep carpet cleaning</li>
            <li>Upholstery & furniture cleaning</li>
            <li>Laminate & hard floor washing</li>
            <li>Mobile car interior detailing</li>
          </ul>
        </div>
        <div className="bg-gray-100 p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-3">Why Choose Us?</h2>
          <p className="mb-2">✔️ Premium German cleaning chemicals</p>
          <p className="mb-2">✔️ Advanced Karcher equipment</p>
          <p className="mb-2">✔️ Fast, friendly & professional service</p>
          <p className="mb-2">✔️ Mid-range affordable pricing</p>
        </div>
      </section>

      <section className="bg-gray-50 py-12 px-4 text-center">
        <h2 className="text-3xl font-bold mb-8">See Our Work</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="bg-gray-200 aspect-video flex items-center justify-center">Before Photo</div>
          </div>
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="bg-gray-200 aspect-video flex items-center justify-center">After Photo</div>
          </div>
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="bg-gray-200 aspect-video flex items-center justify-center">Cleaning Video</div>
          </div>
        </div>
      </section>

      <section className="bg-blue-900 text-white py-10 px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">Contact Us Today</h2>
        <p className="mb-2">📞 +1 (403) 123-4567</p>
        <p className="mb-2">📧 bb.cleaning@example.com</p>
        <p className="mb-4">📸 Instagram: @bb.cleaning</p>
        <button className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-semibold py-3 px-6 rounded-lg text-lg">Request Service</button>
      </section>
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<BBWebsite />);

export default BBWebsite;
